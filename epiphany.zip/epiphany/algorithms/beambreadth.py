class BeamBreadth:

    def __init__(self):
        pass